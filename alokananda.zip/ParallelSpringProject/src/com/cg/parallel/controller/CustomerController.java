package com.cg.parallel.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;
import com.cg.parallel.exception.BankException;
import com.cg.parallel.service.ICustomerService;

@Controller
public class CustomerController {
	@Autowired
	ICustomerService isc;

	public ICustomerService getIsc() {
		return isc;
	}

	public void setIsc(ICustomerService isc) {
		this.isc = isc;
	}

	@RequestMapping("/menu")
	public String menu() {
		return "menu";

	}

	@RequestMapping("/AddCustomer")
	public ModelAndView addCustomer() {
		Customer customer = new Customer();
		return new ModelAndView("AddCustomer", "customer", customer);
	}

	@RequestMapping("/Success")
	public ModelAndView success(@ModelAttribute("customer") @Valid Customer customer, BindingResult result) {
		ModelAndView mv = null;

		if (!result.hasErrors()) {
			int id = isc.addCustomer(customer);
			mv = new ModelAndView("Success", "id", id);

		} else {
			mv = new ModelAndView("AddCustomer", "customer", customer);
		}
		return mv;
	}

	@RequestMapping("/ShowBalance")
	public String showBalance() {
		return "ShowBalanceForm";

	}

	@RequestMapping("/show")
	public ModelAndView showBalance(@RequestParam("id") int id, Model m) {
		ModelAndView mv = new ModelAndView();
		Customer customer = isc.showBalance(id);
		mv.setViewName("ShowingBalance");
		mv.addObject("balance", customer.getBalance());
		return mv;
	}

	@RequestMapping("/BalanceRetrieve")
	public ModelAndView depositMoney(@RequestParam("id") int id, @RequestParam("amt") double amt, Model m) {
		try {
			isc.depositMoney(id, amt);
		} catch (BankException e) {
			// TODO Auto-generated catch block

			throw new BankException(e.getMessage());

		}
		return new ModelAndView("Success", "id", id);

	}

	@RequestMapping("/DepositMoney")
	public String deposit() {
		return "DepositMoney";
	}

	@RequestMapping("/WithdrawMoney")
	public String withdraw() {
		return "WithdrawMoney";
	}

	@RequestMapping("/BalanceWithdraw")
	public ModelAndView withdrawMoney(@RequestParam("id") int id, @RequestParam("amt") double amt, Model m) {
		Transaction t = isc.withdrawMoney(id, amt);
		return new ModelAndView("Success", "id", id);
	}

	@RequestMapping("/showFundTransfer")
	public String showFundTransfer() {
		return "FundTransfer";

	}

	@RequestMapping("/fundTransfer")
	public ModelAndView fundTransfer(@RequestParam("id") int id, @RequestParam("id2") int id2,
			@RequestParam("amt") double amt, Model m) {

		isc.fundTransfer(id, id2, amt);

		return new ModelAndView("Success", "id", id);

	}
	@RequestMapping("/ShowAllAccountHolder")
	public ModelAndView showAll() {
		List<Customer> customer = isc.getAllDetails();
		return new ModelAndView("ShowAllAccountHolder", "customer",customer);
	}
	@RequestMapping("/delete")
	public ModelAndView delete(@RequestParam("id") int id) {
		if(isc.deleteCustomer(id)) {
			return new ModelAndView("menu","msg","Deleted Successfully");
		}
		else {
			return new ModelAndView("ShowAllAccountHolder","msg","Haven't deleted,enter again");
			
		}
	}
	@RequestMapping("/showallsame")
	public ModelAndView showallsame(@RequestParam("name") String name) {
		List<Customer> customer2 = isc.getSame(name);
		return new ModelAndView("ShowAllSame","customer2",customer2);
		
	}
	
}
