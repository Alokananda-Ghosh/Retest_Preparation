package com.cg.parallel.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;
import com.cg.parallel.dao.ICustomerDao;

@Service
@Transactional
public class CustomerService implements ICustomerService{
	@Autowired
	ICustomerDao icd;

	public ICustomerDao getIcd() {
		return icd;
	}

	public void setIcd(ICustomerDao icd) {
		this.icd = icd;
	}

	@Override
	public int addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return icd.addCustomer(customer);
	}

	@Override
	public Customer showBalance(int id) {
		// TODO Auto-generated method stub
		return icd.showBalance(id);
	}

	@Override
	public Transaction depositMoney(int id, double amt) {
		// TODO Auto-generated method stub
		return icd.depositMoney(id, amt);
	}

	@Override
	public Transaction withdrawMoney(int id, double amt) {
		// TODO Auto-generated method stub
		return icd.withdrawMoney(id, amt);
	}

	@Override
	public Transaction fundTransfer(int id, int id2, double amt) {
		// TODO Auto-generated method stub
		return icd.fundTransfer(id, id2, amt);
	}

	@Override
	public List<Customer> getAllDetails() {
		// TODO Auto-generated method stub
		return icd.getAllDetails();
	}

	@Override
	public List<Transaction> getAllTransactionDetails() {
		// TODO Auto-generated method stub
		return icd.getAllTransactionDetails();
	}

	public boolean deleteCustomer(int id) {
		// TODO Auto-generated method stub
		return icd.deleteCustomer(id);
	}

	@Override
	public List<Customer> getSame(String name) {
		// TODO Auto-generated method stub
		return icd.getSame(name);
	}

	@Override
	public Customer update(int id) {
		// TODO Auto-generated method stub
		return icd.update(id);
	}

}
