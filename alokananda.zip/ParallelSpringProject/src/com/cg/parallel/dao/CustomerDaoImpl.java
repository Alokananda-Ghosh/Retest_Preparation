package com.cg.parallel.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;
import com.cg.parallel.exception.BankException;

@Repository
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int addCustomer(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer.getId();
	}
	@Override
	public Transaction depositMoney(int id, double amt) {
		// TODO Auto-generated method stub
		Customer customer;
		Transaction transaction = new Transaction();
		customer = entityManager.find(Customer.class, id);
		if (customer != null) {
			customer.setBalance(amt + (customer.getBalance()));
			entityManager.merge(customer);
			transaction.setAccno(customer.getId());
			transaction.setTransactiontype("Deposit");
			transaction.setAmount(amt);
			transaction.setDate2(Date.valueOf(LocalDate.now()));
			String t = LocalTime.now() + "";
			transaction.setTime(t);
			entityManager.persist(transaction);
		} else {
			throw new BankException("Invalid Customer id");

		}
		return transaction;
	}

	@Override
	public Transaction withdrawMoney(int id, double amt) {
		// TODO Auto-generated method stub
		Customer customer = entityManager.find(Customer.class, id);
		double bal = customer.getBalance() - amt;
		if (customer != null) {
			customer.setBalance(bal);
			entityManager.merge(customer);
			Transaction transaction = new Transaction();
			transaction.setAccno(customer.getId());
			transaction.setAmount(amt);
			transaction.setTransactiontype("Withdraw");
			String time = LocalTime.now() + "";
			transaction.setTime(time);
			entityManager.persist(transaction);
			return transaction;
		} else
			throw new BankException("Enter valid id");
	}

	@Override
	public Transaction fundTransfer(int id, int id2, double amt) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		Customer customer = entityManager.find(Customer.class, id);
		Customer customer2 = entityManager.find(Customer.class, id2);
		double bal = customer.getBalance() - amt;
		double bal2=customer2.getBalance() + amt;
		if (bal >= 0) {
			customer.setBalance(bal);
			customer2.setBalance(bal2);
		}
		entityManager.merge(customer);
		entityManager.merge(customer2);
		Transaction transaction = new Transaction();
		transaction.setAccno(customer.getId());
		transaction.setAccno(customer2.getId());
		transaction.setAmount(amt);
		transaction.setAmount(customer2.getBalance());
		transaction.setTransactiontype("fund transfer");
		transaction.setDate2(Date.valueOf(LocalDate.now()));
		String t = LocalTime.now() + "";
		transaction.setTime(t);
		entityManager.persist(transaction);
		return transaction;

	}

	@Override
	public List<Customer> getAllDetails() {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query = entityManager.createQuery("SELECT customer FROM Customer customer",
				Customer.class);
		return query.getResultList();
	}

	@Override
	public List<Transaction> getAllTransactionDetails() {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> query = entityManager.createQuery("SELECT tran FROM Transaction tran",
				Transaction.class);
		return query.getResultList();
	}

	@Override
	public Customer showBalance(int id) {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query = entityManager
				.createQuery("SELECT customer FROM Customer customer where customer.id=:pid", Customer.class);
		query.setParameter("pid", id);

		return query.getSingleResult();
	}

	@Override
	public boolean deleteCustomer(int id) {
		// TODO Auto-generated method stub
		Customer customer = entityManager.find(Customer.class, id);
		if (customer != null) {
			entityManager.remove(customer);
			return true;
		}
		return false;
	}
	@Override
	public List<Customer> getSame(String name) {
		// TODO Auto-generated method stub
		TypedQuery<Customer> query = entityManager
				.createQuery("SELECT customer FROM Customer customer where customer.name=:pname", Customer.class);
		query.setParameter("pname", name);
		return query.getResultList();
	}
	public Customer update(int id) {
		TypedQuery<Customer> query = entityManager
				.createQuery("SELECT customer FROM Customer customer where customer.id=:pid", Customer.class);
		query.setParameter("pname",id);

		return query.getSingleResult();
	}

}
