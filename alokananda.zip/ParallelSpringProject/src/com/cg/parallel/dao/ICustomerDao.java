package com.cg.parallel.dao;

import java.util.List;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;

public interface ICustomerDao {
	public int addCustomer(Customer customer);

	Customer showBalance(int id);

	public Transaction depositMoney(int id, double amt);

	public Transaction withdrawMoney(int id, double amt);

	public Transaction fundTransfer(int id, int id2, double amt);

	List<Customer> getAllDetails();

	List<Transaction> getAllTransactionDetails();

	public boolean deleteCustomer(int id);

	List<Customer> getSame(String name);

	public Customer update(int id);
}
